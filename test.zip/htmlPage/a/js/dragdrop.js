var $ = $;
var events = (function(){
  var topics = {};
  var hOP = topics.hasOwnProperty;

  return {
    subscribe : function(topic, listener) {
      if(!hOP.call(topics, topic)) topics[topic] = [];
      var index = topics[topic].push(listener) -1;
      return {
        remove: function() {
          delete topics[topic][index];
        }
      };
    },
    publish : function(topic, info) {
      if(!hOP.call(topics, topic)) return;
      topics[topic].forEach(function(item) {
            item(info != undefined ? info : {});
      });
    }
  };
})();

var aha;
aha = (function(){
    var  init;
    
    init = function(){
        aha.blackHole.init();
        aha.component.init($('#component'));
        aha.template.init( $('#template') );
    };
    
    return {init : init };
})();

aha.fake = (function(){
    var template, component;
    
    template = {
        area : [
            [],
            [3,1,2],
            [2,1,1],
            [1,1],
            [2,1,1]
        ]
    };
    
    component = [
        ['component_1', '组件1', 'comp-mock-1'],
        ['component_2', '组件2', 'comp-mock-2'],
        ['component_3', '组件3', 'comp-mock-3']
    ];
    
    return { template : template , component : component };
})();

aha.module = (function(){
    var template, component,
    isFake = 1;
    
    template = (function(){
        var get;
        get = function(){
            if ( isFake ){
                return aha.fake.template;
            }
        };
        return { get : get };
    })();
    
    component = (function(){
        var get;
        get = function(){
            if ( isFake ){
                return aha.fake.component;
            }
        };
        return { get : get };
    })();
    
    return { template : template , component : component };
})();

aha.blackHole = (function(){
    var jqMap = {},
    get, init, setJqMap,
    here = $('#black_hole');
    
    setJqMap = function(){
        var div = $('<div></div>');
        var data = aha.module.component.get();
        var temp_ct = div.clone().addClass('container').append(
                        div.clone().addClass('wrapper').append(
                            div.clone().addClass('select-layer')));
            
        jqMap = {
            div : div,
            temp_ct : temp_ct
        };
        
        data.forEach(function(item){
            jqMap[item[0]] = div.clone().addClass(item[2]).text(item[1]);
        });
    };
    
    get = function (str){
        return jqMap[str];
    };
    
    init = function () {
        setJqMap();
    };
    
    return { init : init , get : get , here : here };
})();

aha.component = (function(){
    var div,jqMap,
    configMap = {
        ctName : 'comp-1'
    },
    status = {
        offsetX : 0,
        offsetY : 0,
        selected : null,
        clone : null
    },
    init, fill, process, mousedown, mousemove, mouseup;
    
    fill = function(){
        var data = aha.module.component.get();
        data.forEach(function(item){
            jqMap.container.append(
                div.clone().addClass( configMap.ctName ).attr('data-name', item[0]).text(item[1]));
        });
    };
    
    mousedown = function( e ){
        var cliX, cliY, t;
        cliX = e.clientX;
        cliY = e.clientY;
        t = e.target;
        e.stopPropagation();
        while(t != this && t != null){
            if(t.className == configMap.ctName){
                var clientRect = t.getBoundingClientRect();
                status.offsetX = cliX - clientRect.left;
                status.offsetY = cliY - clientRect.top;
                status.selected = t;
                status.clone = $(t).clone();
                t.classList.add('comp-selected');
                status.clone.css({"position": "absolute" , "left" : t.offsetLeft , "top": t.offsetTop,"width": t.clientWidth,"box-sizing":"border-box"});
                $('body').append(status.clone);
                $(document).on('mousemove',mousemove);
                $(document).on('mouseup',mouseup);
                break;
            }
            t = t.parentElement;
        }
    };
    
    mousemove = function( e ){
        status.clone.css({
            "top" : e.clientY - status.offsetY + document.body.scrollTop ,
            "left": e.clientX - status.offsetX + document.body.scrollLeft
        });
        aha.template.active(e.clientX, e.clientY);
    };
    
    mouseup = function(){
        aha.template.drop(status.clone.attr('data-name'));
        status.clone.remove();
        status.selected.classList.remove('comp-selected');
        status.clone = null;
        $(document).off('mousemove',mousemove);
        $(document).off('mouseup',mouseup);
    };
    
    process = function(){
        jqMap.container.on('mousedown', mousedown);
    };
    
    init = function(cont){
        div = aha.blackHole.get('div');
        jqMap = { container : cont };
        fill();
        process();
    };
    
    return { init : init };
})();

aha.template = (function(){
    var jqMap, wrapper, show_me, div, temp_ct,
    record = {
        header : {},
        body : {},
        footer : {},
        html : ''
    },
    status = {
        data : null,
        area : [],       //所有区域的引用
        list : {},       //所有区域的对应子单元的引用
        active : null,   //鼠标所在的区域
        subActive : null,//鼠标所在的子单元
        subBA : 1,
        table : [],     //选中元素所在区域的所有子节点的Y坐标列表
        clone : null,   //克隆元素
        select : null,  //选中的元素
        selectA : '',   //选中的元素所在的区域
        offsetX : 0,    //克隆元素的起始顶点与鼠标的距离
        offsetY : 0,    //克隆元素的起始顶点与鼠标的距离
        width : 0       //克隆元素的宽度
    },
    init, fill, locate, drop, getRecord, active,getSt, mousedown, mousemove, mouseup,moving,save;
    
    drop = function(str){
        aha.blackHole.here.append(show_me);
        if(status.active != null){
            var t = new Date().getTime();
            var dataName = status.active.attr('data-name');
            var sub = temp_ct.clone();
            var id = 'pre_' + t;
            sub.attr('data-name',str).find('.wrapper').append(aha.blackHole.get(str).clone().attr('id', id));
            if(!record.body[dataName].length){
                status.active.empty();
                record.body[dataName] = [str];
                status.list[dataName] = [sub];
                status.active.append(sub);
            } else {
                if(status.subActive != null){
                    var idx = status.list[dataName].indexOf(status.subActive);
                    status.list[dataName].splice(idx, 0, sub);
                    record.body[dataName].splice(idx, 0, str);
                    status.subActive.before(sub);
                } else {
                    record.body[dataName].push(str);
                    status.list[dataName].push(sub);
                    status.active.append(sub);
                }
            }

            // status.active.append( 
            //     sub.append(
            //          aha.blackHole.get(str).clone().attr('id', id) ));
            status.active = null;
            status.subActive = null;
        }
    };
    
    save = function(){
        
    };
    
    fill = function(){
        var rowNode,
        i, j, k, 
        className, dataName;
        
        wrapper = div.clone();
        status.data = aha.module.template.get();
        var area_al = status.data.area;
        for(i = 1; i < area_al.length; i++){
            rowNode = div.clone().addClass('pure-g');
            k = area_al[i].length;
            for(j = 1; j < k; j++){
                dataName = 'area_' + i + '_' + j;
                className = 'pure-u-' + area_al[i][j] + '-' + area_al[i][0];
                status.area[status.area.length] = div.clone().attr('data-name', dataName).addClass(className);
                rowNode.append( status.area[status.area.length - 1] );
                record.body[dataName] = [];
                status.list[dataName] = [];
            }
            wrapper.append(rowNode);
            rowNode = null;
        }
        record.html = wrapper.html();
        for(i = 0; i < status.area.length ; i++){
            status.area[i].append(
                temp_ct.clone().append(
                    div.clone().addClass('def-div')));
        }
        jqMap.tpl.append(wrapper);
    };
    
    active = function(x, y){
        var tmp = locate(x, y);
        if(tmp[0] != status.active || tmp[0] != null){
            if(tmp[0] == null){
                aha.blackHole.here.append(show_me);
            } else {
                var dataName = tmp[0].attr('data-name');
                if(!record.body[dataName].length){
                    tmp[0].prepend(show_me);
                } else {
                    if(tmp[1] == null){
                        tmp[0].append(show_me);
                    } else {
                        tmp[1].before(show_me);
                    }
                }
            }
            status.subActive = tmp[1];
            status.active = tmp[0];
        }
    };
    
    locate = function(x, y){
        var clientRect, subClientRect, tmp = null, subTmp = null;
        for(var i = 0; i < status.area.length; i++ ){
            clientRect = status.area[i].get(0).getBoundingClientRect();
            if(y < clientRect.bottom && x < clientRect.right && x > clientRect.left && y > clientRect.top){
                tmp = status.area[i];
                break;
            }
        }
        
        if(tmp != null){
            var dataName = tmp.attr('data-name');
            if(tmp != status.active){
                status.table = [];
                if(!!record.body[dataName].length){
                    for(var k = 0; k < status.list[dataName].length; k++){
                        subClientRect = status.list[dataName][k].get(0).getBoundingClientRect();
                        status.table.push( (subClientRect.top + subClientRect.bottom) / 2 );
                    }
                }
            }
            
            for(var k = 0; k < status.table.length; k++){
                if(y  < status.table[k]){
                    subTmp = status.list[dataName][k];
                    break;
                }
            }
        }
        return [tmp, subTmp,k];
    };
    
    
    getRecord = function(){
        return JSON.stringify(record);
    };
    
    getSt = function(){
        return status;
    };
    
    moving = function(){
        aha.blackHole.here.append(show_me);
        var from_dataName = status.selectA;
        if(status.active){
            var target_dataName = status.active.attr('data-name');
            var list = status.list[from_dataName];
            var idx2 = status.list[target_dataName].indexOf(status.subActive);
            var seParent = status.select.parentElement;
            for(var i = 0; i < list.length ; i++){
                if(list[i].get(0) == status.select){
                    break;
                }
            }
            if (!status.list[target_dataName].length){
                status.active.empty();
            }
            if (status.subActive) {
                if (from_dataName == target_dataName && idx2  && idx2 != i ){
                    idx2 = idx2 - 1;
                }
                status.list[target_dataName].splice(idx2, 0, status.list[from_dataName].splice(i,1)[0]);
                record.body[target_dataName].splice(idx2, 0, record.body[from_dataName].splice(i,1)[0]);
                status.subActive.before(status.select);
            } else {
                status.list[target_dataName].push(status.list[from_dataName].splice(i,1)[0]);
                record.body[target_dataName].push(record.body[from_dataName].splice(i,1)[0]);
                status.active.append(status.select);
            }
            if (!status.list[from_dataName].length){
                seParent.appendChild(
                    temp_ct.clone().append(
                        div.clone().addClass('def-div')).get(0));
            }
        }
        status.active = null;
    };
    
    mousemove = function(e){
        status.clone.style.cssText = 'top:' + (e.clientY - status.offsetY + document.body.scrollTop) + 
                                        'px;left:' + (e.clientX - status.offsetX + document.body.scrollLeft) + 'px;width:' + status.width + 'px';
        active(e.clientX, e.clientY);
        //console.log(status.clone.style.cssText);
        // status.clone.style['top'] = (e.clientY - status.offsetY + document.body.scrollTop) + 'px';
        // status.clone.style['left'] = (e.clientX - status.offsetX + document.body.scrollLeft) + 'px';
    };
    
    mouseup = function(){
        moving();
        status.clone.parentElement.removeChild(status.clone);
        status.clone = null;
        status.select.classList.remove('comp-selected');
        $(document).off('mousemove', mousemove);
        $(document).off('mouseup', mouseup);
    };
    
    mousedown = function(e){
        if(~e.target.className.indexOf('select-layer')){
            status.select = e.target.parentElement.parentElement;
            var clientRect = status.select.getBoundingClientRect();
            status.offsetX = e.clientX - clientRect.left;
            status.offsetY = e.clientY - clientRect.top;
            status.clone = status.select.cloneNode(true);
            status.clone.classList.add('clone');
            status.width = clientRect.width;
            status.clone.style.cssText = 'width:'+clientRect.width+'px;top:' + clientRect.top + 'px';
            status.select.parentElement.appendChild(status.clone);
            //status.select.classList.add('comp-selected');
            $(document).on('mousemove', mousemove);
            $(document).on('mouseup', mouseup);
            //console.log('select ',status.select.parentElement.getAttribute('data-name'));
            status.selectA = status.select.parentElement.getAttribute('data-name');
        }
    };
    
    init = function(cont){
        div = aha.blackHole.get('div');
        temp_ct = aha.blackHole.get('temp_ct');
        show_me = temp_ct.clone().append(
                div.clone().addClass('show-me'));
        jqMap = { tpl : cont };
        fill();
        cont.on('mousedown', mousedown);
    };
    
    return { init : init , locate : locate , drop : drop , getRecord : getRecord , active : active , getSt : getSt, save : save};
})();



aha.util = (function(){
    var getData, postData;
    
    getData = function(){
        
    };
    
    postData = function(data,url,ev){
        
    };
    
    return { getData : getData , postData : postData };
})();

