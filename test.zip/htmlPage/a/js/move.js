var events = (function(){
  var topics = {};
  var hOP = topics.hasOwnProperty;

  return {
    subscribe: function(topic, listener) {
      if(!hOP.call(topics, topic)) topics[topic] = [];
      var index = topics[topic].push(listener) -1;
      return {
        remove: function() {
          delete topics[topic][index];
        }
      };
    },
    publish: function(topic, info) {
      if(!hOP.call(topics, topic)) return;
      topics[topic].forEach(function(item) {
            item(info != undefined ? info : {});
      });
    }
  };
})();


var sibar = (function() {
    var init, conf;

    conf = function (){

    }

    init = function (){
        sibar.template.init();
        sibar.comp.init();
    }

    return { init : init};
})();

sibar.comp = (function(){
    var jqMap = {},
    conf = {
        component_1 : '<div class="comp-mock comp-mock-1">component1</div>',
        component_2 : '<div class="comp-mock comp-mock-2">component2</div>',
        component_3 : '<div class="comp-mock comp-mock-3">component3</div>'
    },
    statusMap = {
        startX : 0,
        startY : 0,
        comp_name : '',
    },
    setJqMap, mouseup, mousemove, mousedown, init;

    setJqMap = function (){
        var comps = $('.component');
        jqMap = {
            comps : comps,
            curr : null
        };
    }

    mouseup = function (){
        sibar.template.drop([
            statusMap.comp_name,
            conf[statusMap.comp_name]
        ]);
        jqMap.curr.removeClass('active');
        jqMap.curr.css({top: 0, left : 0});
        jqMap.curr = null;
        $(document).off('mouseup');
        $(document).off('mousemove');
    }

    mousemove = function (event){
        jqMap.curr.css({
            left: event.clientX - statusMap.startX ,
            top : event.clientY - statusMap.startY
        });

        sibar.template.active({
            x:event.clientX ,
            y:event.clientY
        });
    }

    mousedown = function (event){
        event.preventDefault();
        //console.log(event);
        jqMap.curr = $(event.target);
        statusMap.comp_name = jqMap.curr.attr('data-compname');
        statusMap.startX = event.clientX;
        statusMap.startY = event.clientY;
        jqMap.curr.addClass('active');
        $(document).on('mouseup', mouseup).on('mousemove', mousemove);
    }

    init = function (){
        setJqMap();
        $('#sidebar').on('mousedown', mousedown);
    }

    return { init : init };
})();

sibar.template = (function(){
    var init,
    conf = {
        def_html : '<div class="def-div"></div>'
    },
    statusMap = {
        active : '',
        template_name : 'template-1',
        area : {
            area_1_1 : [],
            area_1_2 : [],
            area_1_3 : [],
            area_2_1 : [],
            area_2_2 : [],
            area_3_1 : []
        }
    },
    coords = {
        line : [],
        lineHeight : []

    },
    jqMap = {},
    setJqMap, active,drop,logAll,updateCoords;

    active = function ( cursor ){   // 定位顺序  行 列 单元
        var curr, diffX, diffY,
        tmp = '';

        for(var i = 0; i < jqMap.areas.length ; i++ ){
            curr = jqMap.areas[i].getBoundingClientRect();
            diffX = cursor.x - curr.left;
            if( diffX >= 0  && diffX < curr.width && cursor.y <= curr.bottom){
                tmp = jqMap.areas[i].id;
                break;
            }
        }
        
        // if(tmp != '' && statusMap.area[tmp].length != 0){
        //     jqMap.all.find('#' + tmp).find('.comp-mock').each(function(){
        //         console.log($(this)[0].getBoundingClientRect());
        //     });
        // }

        if(tmp != statusMap.active){
            if(tmp != ''){
                //jqMap.all.find('#' + tmp).addClass('active');
                //$('#insert-div').remove();
                jqMap.all.find('#' + tmp).prepend($("#insert_div"));
                $("#insert_div").show();
            } else {
                $("body").append($("#insert_div"));
                $("#insert_div").hide();
            }
            // if(statusMap.active != ''){
            //     //jqMap.all.find('#' + statusMap.active).removeClass('active');
            //     jqMap.all.find('#' + tmp).append('<div id="insert-div"></div>');
            // }
            statusMap.active = tmp;
        }
    }

    drop = function ( args ){
        $("body").append($("#insert_div"));
        $("#insert_div").hide();
        if (statusMap.active != '') {
            //console.log(statusMap.active);
            jqMap.all.find('#' + statusMap.active).removeClass('active');
            if (statusMap.area[statusMap.active].length == 0){
                jqMap.all.find('#' + statusMap.active).html(args[1]);
            } else {
                jqMap.all.find('#' + statusMap.active).append(args[1]);
            }
            statusMap.area[statusMap.active].push(args[0]);
            statusMap.active = '';
        }
    }

    setJqMap = function (){
        var areas = $('.component-area');
        var all = $("#template");
        jqMap = {
            areas : areas,
            all : all
        };
    }

    logAll = function (){
        console.log(JSON.stringify(statusMap));
    }

    updateCoords = function (){

    }

    init = function (){
        setJqMap();
    }

    return { init : init , active : active , drop : drop , logAll : logAll };
})();

