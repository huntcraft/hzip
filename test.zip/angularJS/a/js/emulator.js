angular.module('switch', [])
.directive('tabswitch', function($rootScope){
    return function(scope, element, attrs){
        $rootScope.$on('tab.switch', function(event, msg){
            if(element.attr('data-text') != msg){
                element.removeClass("active");
            } else {
                element.addClass("active");
            }
        });
        element.on('click', function(){
            if(element.hasClass("active")){
                return false;
            } else {
                $rootScope.$emit("tab.switch", element.attr('data-text'));
            }
        });
    };
})
.directive("cssswitch", function($rootScope){
    return function(scope, element, attr){
        $rootScope.$on("tab.switch", function(event, msg){
            if(element.attr('data-text') == msg){
                element.removeAttr("disabled");
            } else {
                element.attr("disabled", "disabled");
            }
        });
    };
});